
SELECT TOP (1) [Id]
      
  FROM [Task2].[dbo].[Order] WHERE YEAR([OrderDate]) = 2019 ORDER BY [OrderDate]